G2 COFFEE SHOP - GROUP 2
HTML WEBSITE PROJECT

Files:
- index.html  = Home
- about.html  = About Us
- menu.html   = Menu
- contact.html = Contact
- style.css   = Shared CSS
- images/g2-logo.jpg = G2 Coffee Shop logo

To open:
1. Extract the ZIP.
2. Open index.html in a web browser.
3. Use the navigation buttons to visit the other pages.

The website uses HTML and CSS only and includes responsive design and hover effects.
